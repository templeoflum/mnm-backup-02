# RESEARCH OPERATION — Distill a Corpus into Mind, not Map

*One operation, addressed on the lattice's own structure: every position is a 0/1/2 choice (is/does/goes → ground/do/document), three deep by choice to contain the frame. The root is the operation itself — the frame that holds all 27 addresses, not a position among them. Addresses are the lattice's ternary addresses used as a **planning instrument**: 0.0.0 = III, 1.1.1 = DDD, 2.2.2 = GGG. Same object, dressed for planning.*

*Status: proposed structure, not settled. Targets are filled where the work is; the cell level (third digit) is what a leaf unfolds into when pulled. Nothing here is crowned — staged to be walked and settled.*

---

## The bet (what the whole operation tests)

Use the lattice as the **instrument that sorts and condenses a public-commons corpus into a small, dense, high-integrity reasoning set**, and show a small model reasoning *through* that set reasons (mind) rather than retrieves (map) — and does so better than the same model over flat, unstructured material. Leverage is **curation quality, not scale.** Empirical backing exists: small curated sets (LIMA: ~1,000 examples → teacher-level) and distillation that transfers generalization while leaving memorization behind. "Mind not map" is the same distinction as TS's relational-not-intrinsic thesis: a mind reasons relationally; a map stores positions.

---

## THE OPERATION (27-cell address space; filled where the work is)

```
[ root ] — distill a corpus into a set that makes a small model reason, not retrieve

0 · GROUND — establish what must hold first (the cheap kills)
  0.0  placement reality        — can text be placed at all?
     0.0.0  define the address-anchors (what each mode/topic "looks like")
     0.0.1  run embeddings, attempt the separation
     0.0.2  record: do they separate? kill-or-proceed
  0.1  mind/map probe           — a reasoning test memorization can't game
     0.1.0  define "reasoning, not memorizing" for this corpus
     0.1.1  build the held-out probe (post-cutoff / sorting-style)
     0.1.2  record the probe + its pass-bar
  0.2  fair baseline            — the flat control, specified before building
     0.2.0  what the flat control must hold equal (same material, same retrieval)
     0.2.1  build the flat control set
     0.2.2  record the baseline's measured floor

1 · DO — build the toys (hands-on, the on-ramp)
  1.0  the tiny sorter
     1.0.0  smallest bounded corpus to sort
     1.0.1  ML proposes → human signs the placements
     1.0.2  record the sorted set + placement agreement rate
  1.1  the folder              — the dead center; least-specified, most important
     1.1.0  what "condense" means here; what must survive a fold
     1.1.1  fold a sample by hand   (= DDD, do-of-do-of-do)
     1.1.2  record the folding rule that worked
  1.2  retrieval-through
     1.2.0  set up retrieval over the folded set
     1.2.1  model reasons through it, no fine-tune
     1.2.2  record the first mind-not-map signal (or absence)

2 · DOCUMENT — measure, formalize, plan the next layer
  2.0  folded-vs-flat          — THE BLADE: does structure beat flat?
     2.0.0  lock the comparison conditions
     2.0.1  run folded vs flat on the probe
     2.0.2  record the verdict — the bet lives or dies here
  2.1  distillation protocol   — IF signal
     2.1.0  what exactly to distill
     2.1.1  draft the logit-level distillation approach
     2.1.2  record the protocol
  2.2  scale schema + gate     — what the next layer builds on
     2.2.0  what the next-bigger layer needs
     2.2.1  define the escalation gate to the far star (multimodal synthesis)
     2.2.2  the signed record passed forward   (= GGG, sign·hands·record)
```

---

## The corners (a small confirmation, not a forcing)

The three pure-digit addresses landed on their own lattice meanings unforced:
- **0.0.0 (III)** — define-the-anchors: the ground-of-ground, the absolute first feasibility.
- **1.1.1 (DDD)** — fold-by-hand: dead center, the most hands-on core act.
- **2.2.2 (GGG, sign·hands·record)** — the signed record passed forward: the attestation that closes the cycle and feeds the next.

The within-cell pattern also held nine times without imposing: every leaf's three cells read **0 = define/set-up · 1 = do-the-thing · 2 = record** — the ground/do/document cycle one level down. Held soft ("the three a step needs," not a proven law).

---

## Gates (real, not ceremonial)

- **0 gates 1 gates 2.** If placement doesn't separate (0.0) or mind can't be told from map (0.1), the do-branch doesn't run. Earned depth.
- **2.0 is the hard gate within DO→DOCUMENT:** no signal at the blade → 2.1 (distillation) and the far-star gate (2.2.1) don't open.
- Start by *deciding which to pull* (the center move), not necessarily 0.0 — though the cheap kills make the ground branch a sound first pull.

## Open seams (left open, not smoothed)

- **1.2.x and 2.0.x are nearly the same experiment from two sides** — "does reasoning over the folded set beat flat?" 1.2 is *doing* it (the toy runs), 2.0 is *measuring* it (against control). The seam where do hands to document. May be one target wearing two labels.
- **The leaf-mode assignments are softer than the branch ones.** That 0.1 is "do-within-ground" reads, but the *branch* assignment (ground/do/document) is solid; the leaf-mode is more "the three a phase needs" than a proven sub-cycle.

## The far star (parked, gated behind the whole operation)

Real-time multimodal synthesis (the synthesis-engine north star). The field has converged on joint audio-video generation in unified single-tower architectures — which *validates the structural intuition* (model the joint, don't stitch modules) but is nowhere near buildable here. The lattice's plausible near-term role is a composition/control layer over existing joint models, not a model. Gate at 2.2.1.

---

## Note: the lattice as a planning instrument

This operation is addressed on the lattice's own 0/1/2 ternary structure — the same addresses as the concept-lattice (0.0.0=III, 1.1.1=DDD, 2.2.2=GGG), just dotted for legibility. Plan/outline numbering *is* lattice addressing; the lattice makes the base (3) and the meaning-per-digit (mode) explicit. This is the lattice used for planning rather than concept-mapping — same structure, different room. (Connects to the walkable-data / file-system intuition: the structure holds where things go because position is meaning.)

*Proposed. Yours to walk and settle.*
